﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Synthesis;
using WebCam_Capture;
using AForge.Video;
using AForge.Video.DirectShow;
using System.Diagnostics;

namespace Camera
{
    public partial class Form1 : Form
    {
        SpeechSynthesizer sp;
        public Form1()
        {
            InitializeComponent();
            sp = new SpeechSynthesizer();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string user = txtUser.Text;
            string pass = txtPass.Text;
            if (user == "Shwet" && pass == "1234")
            {
                sp.Speak("Welcome " + user + "Now You Can start your Work");
                this.Hide();
                Form1 ob = new Form1();
                ob.Show();
            }
            else
            {
                sp.Speak("Invalid Login");
                Process p = new Process();
                p.StartInfo.FileName = "camcap.exe";
                p.Start();
                Application.ExitThread();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            sp.Speak("Welcome User...Please Provide with your Credentials"); 

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            sp.Speak("Thankyou for your visit");
            Application.ExitThread();
        }
    }
}
